"""
db.py — 数据库操作层
支持多用户：users / subscriptions(per-user) / videos(共享) / user_history / user_interests
"""
import sqlite3
import json
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path

DB_PATH = Path(__file__).parent / "radar.db"


@contextmanager
def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    try:
        yield c
        c.commit()
    except Exception:
        c.rollback()
        raise
    finally:
        c.close()


def init_db():
    with conn() as c:
        c.executescript("""
        -- 用户表（token 即身份，无需注册）
        CREATE TABLE IF NOT EXISTS users (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            token      TEXT    UNIQUE NOT NULL,  -- web: UUID  |  tg: chat_id
            source     TEXT    DEFAULT 'web',    -- 'web' | 'telegram'
            created_at TEXT    DEFAULT (datetime('now'))
        );

        -- 订阅表（per-user）
        CREATE TABLE IF NOT EXISTS subscriptions (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            channel_id   TEXT    NOT NULL,
            channel_name TEXT    NOT NULL,
            topic        TEXT,
            created_at   TEXT    DEFAULT (datetime('now')),
            UNIQUE(user_id, channel_id)
        );

        -- 视频报告表（全局共享，同一视频只处理一次）
        CREATE TABLE IF NOT EXISTS videos (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            video_id     TEXT    UNIQUE NOT NULL,
            channel_id   TEXT,
            channel_name TEXT,
            title        TEXT,
            view_count   INTEGER DEFAULT 0,
            published_at TEXT,
            duration     TEXT,
            topic        TEXT,
            transcript   TEXT,
            key_points   TEXT,   -- JSON 数组
            summary      TEXT,
            timestamps   TEXT,   -- JSON 数组
            keywords     TEXT,   -- JSON 数组，用于话题聚合
            created_at   TEXT    DEFAULT (datetime('now')),

            -- 全文搜索字段（FTS5 通过 trigger 维护）
            fts_content  TEXT GENERATED ALWAYS AS (
                coalesce(title,'') || ' ' ||
                coalesce(summary,'') || ' ' ||
                coalesce(key_points,'')
            ) VIRTUAL
        );

        -- FTS5 全文搜索索引
        CREATE VIRTUAL TABLE IF NOT EXISTS videos_fts USING fts5(
            video_id UNINDEXED,
            title,
            summary,
            key_points,
            content='videos',
            content_rowid='id'
        );

        -- FTS 触发器：insert
        CREATE TRIGGER IF NOT EXISTS videos_fts_insert AFTER INSERT ON videos BEGIN
            INSERT INTO videos_fts(rowid, video_id, title, summary, key_points)
            VALUES (new.id, new.video_id, new.title, new.summary, new.key_points);
        END;

        -- FTS 触发器：update
        CREATE TRIGGER IF NOT EXISTS videos_fts_update AFTER UPDATE ON videos BEGIN
            INSERT INTO videos_fts(videos_fts, rowid, video_id, title, summary, key_points)
            VALUES ('delete', old.id, old.video_id, old.title, old.summary, old.key_points);
            INSERT INTO videos_fts(rowid, video_id, title, summary, key_points)
            VALUES (new.id, new.video_id, new.title, new.summary, new.key_points);
        END;

        -- 用户提取历史（记录谁提取了哪个视频）
        CREATE TABLE IF NOT EXISTS user_history (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            video_id   TEXT    NOT NULL,
            created_at TEXT    DEFAULT (datetime('now')),
            UNIQUE(user_id, video_id)
        );

        -- 用户兴趣标签
        CREATE TABLE IF NOT EXISTS user_interests (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            topic      TEXT    NOT NULL,
            created_at TEXT    DEFAULT (datetime('now')),
            UNIQUE(user_id, topic)
        );

        -- 索引
        CREATE INDEX IF NOT EXISTS idx_sub_user    ON subscriptions(user_id);
        CREATE INDEX IF NOT EXISTS idx_sub_channel ON subscriptions(channel_id);
        CREATE INDEX IF NOT EXISTS idx_vid_channel ON videos(channel_id);
        CREATE INDEX IF NOT EXISTS idx_vid_topic   ON videos(topic);
        CREATE INDEX IF NOT EXISTS idx_hist_user   ON user_history(user_id);
        """)
    print(f"[db] initialized → {DB_PATH}")


# ── 用户 ──────────────────────────────────────────────────────


def get_or_create_user(token: str, source: str = "web") -> int:
    """根据 token 获取或创建用户，返回 user_id。"""
    with conn() as c:
        row = c.execute("SELECT id FROM users WHERE token=?", (token,)).fetchone()
        if row:
            return row["id"]
        cur = c.execute(
            "INSERT INTO users(token, source) VALUES(?,?)", (token, source)
        )
        return cur.lastrowid


# ── 订阅 ──────────────────────────────────────────────────────


def add_subscription(user_id: int, channel_id: str, channel_name: str, topic: str = None):
    with conn() as c:
        c.execute(
            "INSERT OR IGNORE INTO subscriptions(user_id,channel_id,channel_name,topic) VALUES(?,?,?,?)",
            (user_id, channel_id, channel_name, topic),
        )


def remove_subscription(user_id: int, channel_id: str):
    with conn() as c:
        c.execute(
            "DELETE FROM subscriptions WHERE user_id=? AND channel_id=?",
            (user_id, channel_id),
        )


def get_subscriptions(user_id: int) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            """SELECT s.channel_id, s.channel_name, s.topic,
                      MAX(v.created_at) AS last_updated
               FROM subscriptions s
               LEFT JOIN videos v ON v.channel_id = s.channel_id
               WHERE s.user_id=?
               GROUP BY s.channel_id
               ORDER BY s.created_at DESC""",
            (user_id,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_all_subscribed_channels() -> list[dict]:
    """monitor.py 用：获取所有用户订阅的去重频道列表。"""
    with conn() as c:
        rows = c.execute(
            "SELECT DISTINCT channel_id, channel_name FROM subscriptions"
        ).fetchall()
        return [dict(r) for r in rows]


# ── 视频 / 报告 ───────────────────────────────────────────────


def video_exists(video_id: str) -> bool:
    with conn() as c:
        row = c.execute(
            "SELECT id FROM videos WHERE video_id=?", (video_id,)
        ).fetchone()
        return row is not None


def save_video(
    video_id: str,
    channel_id: str,
    channel_name: str,
    title: str,
    key_points: list[str],
    summary: str,
    timestamps: list[str] = None,
    keywords: list[str] = None,
    view_count: int = 0,
    published_at: str = None,
    duration: str = None,
    topic: str = None,
    transcript: str = None,
):
    with conn() as c:
        c.execute(
            """INSERT INTO videos
               (video_id,channel_id,channel_name,title,key_points,summary,
                timestamps,keywords,view_count,published_at,duration,topic,transcript)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
               ON CONFLICT(video_id) DO UPDATE SET
                 key_points=excluded.key_points, summary=excluded.summary,
                 timestamps=excluded.timestamps, keywords=excluded.keywords,
                 topic=excluded.topic, transcript=excluded.transcript""",
            (
                video_id, channel_id, channel_name, title,
                json.dumps(key_points, ensure_ascii=False),
                summary,
                json.dumps(timestamps or [], ensure_ascii=False),
                json.dumps(keywords or [], ensure_ascii=False),
                view_count, published_at, duration, topic, transcript,
            ),
        )


def get_video(video_id: str) -> dict | None:
    with conn() as c:
        row = c.execute(
            "SELECT * FROM videos WHERE video_id=?", (video_id,)
        ).fetchone()
        return _parse_video(dict(row)) if row else None


def get_hot_videos(window_days: int = 7, limit: int = 30) -> list[dict]:
    """按 view_count 排序，取最近 N 天内处理的视频。"""
    with conn() as c:
        rows = c.execute(
            """SELECT * FROM videos
               WHERE created_at >= datetime('now', ?)
               ORDER BY view_count DESC
               LIMIT ?""",
            (f"-{window_days} days", limit),
        ).fetchall()
        return [_parse_video(dict(r)) for r in rows]


def get_videos_by_topics(topics: list[str], limit: int = 50) -> list[dict]:
    """按话题过滤，每个话题最多返回 limit/len(topics) 条。"""
    if not topics:
        return []
    placeholders = ",".join("?" * len(topics))
    with conn() as c:
        rows = c.execute(
            f"""SELECT * FROM videos
                WHERE topic IN ({placeholders})
                ORDER BY view_count DESC, created_at DESC
                LIMIT ?""",
            (*topics, limit),
        ).fetchall()
        return [_parse_video(dict(r)) for r in rows]


def search_videos(query: str, limit: int = 20) -> list[dict]:
    """全文搜索（FTS5）。"""
    with conn() as c:
        rows = c.execute(
            """SELECT v.* FROM videos v
               JOIN videos_fts f ON v.id = f.rowid
               WHERE videos_fts MATCH ?
               ORDER BY rank
               LIMIT ?""",
            (query, limit),
        ).fetchall()
        return [_parse_video(dict(r)) for r in rows]


# ── 用户历史 ──────────────────────────────────────────────────


def add_user_history(user_id: int, video_id: str):
    with conn() as c:
        c.execute(
            "INSERT OR REPLACE INTO user_history(user_id,video_id) VALUES(?,?)",
            (user_id, video_id),
        )


def get_user_history(user_id: int, limit: int = 20) -> list[dict]:
    with conn() as c:
        rows = c.execute(
            """SELECT v.* FROM videos v
               JOIN user_history h ON h.video_id = v.video_id
               WHERE h.user_id=?
               ORDER BY h.created_at DESC
               LIMIT ?""",
            (user_id, limit),
        ).fetchall()
        return [_parse_video(dict(r)) for r in rows]


# ── 兴趣标签 ──────────────────────────────────────────────────


def set_user_interests(user_id: int, topics: list[str]):
    with conn() as c:
        c.execute("DELETE FROM user_interests WHERE user_id=?", (user_id,))
        for t in topics:
            c.execute(
                "INSERT OR IGNORE INTO user_interests(user_id,topic) VALUES(?,?)",
                (user_id, t),
            )


def get_user_interests(user_id: int) -> list[str]:
    with conn() as c:
        rows = c.execute(
            "SELECT topic FROM user_interests WHERE user_id=?", (user_id,)
        ).fetchall()
        return [r["topic"] for r in rows]


# ── 内部工具 ──────────────────────────────────────────────────


def _parse_video(row: dict) -> dict:
    for field in ("key_points", "timestamps", "keywords"):
        val = row.get(field)
        if isinstance(val, str):
            try:
                row[field] = json.loads(val)
            except Exception:
                row[field] = []
    # 去掉大字段，避免列表接口传输过多数据
    row.pop("transcript", None)
    row.pop("fts_content", None)
    return row


def _ago(dt_str: str) -> str:
    """把 ISO 时间字符串转成「N天前」。"""
    if not dt_str:
        return ""
    try:
        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
        delta = datetime.now(timezone.utc) - dt
        d = delta.days
        if d == 0:
            return "今天"
        if d == 1:
            return "昨天"
        if d < 7:
            return f"{d}天前"
        if d < 30:
            return f"{d//7}周前"
        return f"{d//30}个月前"
    except Exception:
        return dt_str


def enrich_ago(videos: list[dict]) -> list[dict]:
    """为视频列表添加 published_ago 字段。"""
    for v in videos:
        v["published_ago"] = _ago(v.get("published_at", ""))
    return videos


if __name__ == "__main__":
    init_db()
