import asyncio
from fastapi import APIRouter, Header, HTTPException
from schemas import AskBody, AskResponse
import db
from ._auth import require_user
from generate_report import ask_about_video

router = APIRouter()

@router.post("/api/ask", response_model=AskResponse)
async def api_ask(body: AskBody, x_user_token: str = Header(default=None)):
    require_user(x_user_token)
    v = db.get_video(body.video_id)
    if not v:
        raise HTTPException(404, "视频不存在")
    ctx = f"标题：{v.get('title','')}\n要点：\n"
    ctx += "\n".join(f"- {p}" for p in (v.get('key_points') or []))
    if v.get('summary'):
        ctx += f"\n摘要：{v['summary']}"
    answer = await asyncio.get_event_loop().run_in_executor(
        None, ask_about_video, ctx, body.question)
    return AskResponse(answer=answer)
