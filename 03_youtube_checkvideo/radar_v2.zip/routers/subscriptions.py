import re
from fastapi import APIRouter, Header
from schemas import SubResponse, SubBody, SubOut
import db
from ._auth import require_user

router = APIRouter()


@router.get("/api/subscriptions", response_model=SubResponse)
async def get_subs(x_user_token: str = Header(default=None)):
    uid = require_user(x_user_token)
    return SubResponse(subscriptions=[SubOut(**s) for s in db.get_subscriptions(uid)])


@router.post("/api/subscriptions")
async def add_sub(body: SubBody, x_user_token: str = Header(default=None)):
    uid = require_user(x_user_token)
    cid = _normalize(body.channel)
    db.add_subscription(uid, cid, body.channel.strip(), body.topic or None)
    return {"ok": True, "channel_id": cid}


@router.delete("/api/subscriptions/{channel_id}")
async def del_sub(channel_id: str, x_user_token: str = Header(default=None)):
    uid = require_user(x_user_token)
    db.remove_subscription(uid, channel_id)
    return {"ok": True}


def _normalize(channel: str) -> str:
    m = re.search(r"/channel/(UC[A-Za-z0-9_-]+)", channel)
    if m:
        return m.group(1)
    m = re.search(r"/@([A-Za-z0-9_.-]+)", channel)
    if m:
        return "@" + m.group(1)
    return channel.strip()
