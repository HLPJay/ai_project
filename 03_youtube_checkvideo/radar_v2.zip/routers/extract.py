import asyncio, json, re
from typing import AsyncIterator
from fastapi import APIRouter
from fastapi.responses import StreamingResponse
import db
from generate_report import generate_report
from local_transcript import get_transcript

router = APIRouter()

def _parse_vid(url: str) -> str | None:
    for p in [r"(?:v=|/)([0-9A-Za-z_-]{11})", r"youtu\.be/([0-9A-Za-z_-]{11})"]:
        m = re.search(p, url)
        if m: return m.group(1)
    if re.match(r"^[0-9A-Za-z_-]{11}$", url.strip()):
        return url.strip()
    return None

async def _stream(url: str, token: str) -> AsyncIterator[str]:
    def ev(status, message="", step="", **kw):
        return f"data: {json.dumps({'status':status,'message':message,'step':step,**kw}, ensure_ascii=False)}\n\n"
    try:
        uid = db.get_or_create_user(token.strip(), "web")
        vid = _parse_vid(url)
        if not vid:
            yield ev("error", "无法解析视频链接"); return
        cached = db.get_video(vid)
        if cached:
            db.add_user_history(uid, vid)
            yield ev("done", step="done", video=db.enrich_ago([cached])[0]); return
        yield ev("progress", "获取字幕中…", "transcript")
        loop = asyncio.get_event_loop()
        tr = await loop.run_in_executor(None, get_transcript, vid)
        if not tr or not tr.get("text"):
            yield ev("error", "无法获取字幕"); return
        yield ev("progress", "AI 分析中…", "generating")
        report = await loop.run_in_executor(None, generate_report, tr["text"], tr.get("title",""))
        if not report:
            yield ev("error", "报告生成失败"); return
        db.save_video(video_id=vid, channel_id=tr.get("channel_id",""),
            channel_name=tr.get("channel_name",""), title=tr.get("title",""),
            key_points=report["key_points"], summary=report["summary"],
            timestamps=report.get("timestamps",[]), keywords=report.get("keywords",[]),
            view_count=tr.get("view_count",0), published_at=tr.get("published_at",""),
            duration=tr.get("duration",""), topic=report.get("topic",""), transcript=tr["text"])
        db.add_user_history(uid, vid)
        v = db.enrich_ago([db.get_video(vid)])[0]
        yield ev("done", step="done", video=v)
    except Exception as e:
        yield ev("error", str(e))

@router.get("/report")
async def report_sse(url: str, token: str = ""):
    return StreamingResponse(_stream(url, token), media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})
