from fastapi import APIRouter, Header
from schemas import VideoResponse, VideoOut
import db
from ._auth import require_user

router = APIRouter()

@router.get("/api/history", response_model=VideoResponse)
async def api_history(x_user_token: str = Header(default=None)):
    uid = require_user(x_user_token)
    videos = db.enrich_ago(db.get_user_history(uid, limit=20))
    return VideoResponse(videos=[VideoOut(**v) for v in videos])
