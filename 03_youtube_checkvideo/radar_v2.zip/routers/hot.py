from fastapi import APIRouter, Header
from schemas import HotResponse, VideoOut
import db
from ._auth import require_user

router = APIRouter()


@router.get("/api/hot", response_model=HotResponse)
async def api_hot(
    window: str = "7d",
    x_user_token: str = Header(default=None),
):
    require_user(x_user_token)
    days = int(window.rstrip("d")) if window.endswith("d") else 7
    videos = db.enrich_ago(db.get_hot_videos(window_days=days, limit=30))
    return HotResponse(
        videos=[VideoOut(**v) for v in videos],
        updated_at=f"过去 {days} 天",
    )
