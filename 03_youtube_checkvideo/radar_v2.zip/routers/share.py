from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
import db

router = APIRouter()
templates = Jinja2Templates(directory="templates")

@router.get("/share/{video_id}", response_class=HTMLResponse)
async def share_page(request: Request, video_id: str):
    v = db.get_video(video_id)
    if not v:
        raise HTTPException(404, "视频不存在")
    v = db.enrich_ago([v])[0]
    return templates.TemplateResponse("share.html", {"request": request, "video": v})

@router.get("/", response_class=HTMLResponse)
async def index(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})
