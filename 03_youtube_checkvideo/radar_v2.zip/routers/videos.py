"""
routers/videos.py  GET /api/videos  GET /api/search
"""
from fastapi import APIRouter, Header, HTTPException
from schemas import VideoResponse, VideoOut
import db
from ._auth import require_user

router = APIRouter()


@router.get("/api/videos", response_model=VideoResponse)
async def api_videos(topics: str = "", x_user_token: str = Header(default=None)):
    require_user(x_user_token)
    tlist = [t.strip() for t in topics.split(",") if t.strip()]
    if not tlist:
        raise HTTPException(400, "topics 不能为空")
    videos = db.enrich_ago(db.get_videos_by_topics(tlist, limit=60))
    return VideoResponse(videos=[VideoOut(**v) for v in videos])


@router.get("/api/search", response_model=VideoResponse)
async def api_search(q: str = "", x_user_token: str = Header(default=None)):
    require_user(x_user_token)
    if len(q.strip()) < 2:
        raise HTTPException(400, "关键词太短")
    videos = db.enrich_ago(db.search_videos(q.strip(), limit=20))
    return VideoResponse(videos=[VideoOut(**v) for v in videos])
