"""_auth.py — 共享认证工具，所有 router 从这里导入"""
from fastapi import HTTPException
import db


def require_user(token: str | None) -> int:
    """验证 token 并返回 user_id，token 不存在则 401。"""
    if not token:
        raise HTTPException(status_code=401, detail="缺少 X-User-Token")
    return db.get_or_create_user(token.strip(), source="web")
