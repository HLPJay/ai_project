"""
telegram_bot.py — Telegram Bot
命令：
  /start   欢迎 + 绑定用户
  /watch   <YouTube URL>  提取单个视频
  /sub     <频道URL或名称>  订阅频道
  /unsub   <频道ID>        取消订阅
  /list                   查看我的订阅
  /hot                    今日热门（前5条）
多用户：用 chat_id 作为 token 注册到 users 表（source='telegram'）
"""
import asyncio
import os

from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes

import db
from generate_report import generate_report
from local_transcript import get_transcript
from monitor import register_push

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
PROXY_URL = os.getenv("TELEGRAM_PROXY", "")      # 国内环境：http://127.0.0.1:7890
WEB_BASE  = os.getenv("WEB_BASE_URL", "http://localhost:8000")


# ── 用户绑定 ──────────────────────────────────────────────────


def _uid(update: Update) -> int:
    """把 Telegram chat_id 映射到内部 user_id。"""
    chat_id = str(update.effective_chat.id)
    return db.get_or_create_user(chat_id, source="telegram")


# ── 命令处理 ──────────────────────────────────────────────────


async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = _uid(update)
    await update.message.reply_text(
        "👋 欢迎使用 *视频雷达*\n\n"
        "我会帮你过滤 YouTube 信息噪音，只推送真正值得看的内容。\n\n"
        "快捷命令：\n"
        "`/watch <链接>` — 提取视频要点\n"
        "`/sub <频道>` — 订阅频道\n"
        "`/unsub <频道ID>` — 取消订阅\n"
        "`/list` — 我的订阅\n"
        "`/hot` — 今日热门",
        parse_mode="Markdown",
    )


async def cmd_watch(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("用法：`/watch <YouTube链接>`", parse_mode="Markdown")
        return

    url = ctx.args[0].strip()
    uid = _uid(update)
    msg = await update.message.reply_text("⏳ 正在提取，请稍候…")

    try:
        video_id = _parse_vid(url)
        if not video_id:
            await msg.edit_text("❌ 无法识别链接，请确认是有效的 YouTube 视频 URL")
            return

        # 命中缓存
        cached = db.get_video(video_id)
        if cached:
            db.add_user_history(uid, video_id)
            await msg.edit_text(_format_report(cached), parse_mode="Markdown")
            return

        await msg.edit_text("📝 获取字幕中…")
        loop = asyncio.get_event_loop()

        tr = await loop.run_in_executor(None, get_transcript, video_id)
        if not tr or not tr.get("text"):
            await msg.edit_text("❌ 无法获取字幕，该视频可能没有字幕")
            return

        await msg.edit_text("🤖 AI 分析中…")
        report = await loop.run_in_executor(None, generate_report, tr["text"], tr.get("title",""))
        if not report:
            await msg.edit_text("❌ AI 报告生成失败，请稍后重试")
            return

        db.save_video(
            video_id=video_id,
            channel_id=tr.get("channel_id",""),
            channel_name=tr.get("channel_name",""),
            title=tr.get("title",""),
            key_points=report["key_points"],
            summary=report["summary"],
            timestamps=report.get("timestamps",[]),
            keywords=report.get("keywords",[]),
            view_count=tr.get("view_count",0),
            published_at=tr.get("published_at",""),
            duration=tr.get("duration",""),
            topic=report.get("topic",""),
            transcript=tr["text"],
        )
        db.add_user_history(uid, video_id)

        video = db.get_video(video_id)
        await msg.edit_text(_format_report(video), parse_mode="Markdown")

    except Exception as e:
        await msg.edit_text(f"❌ 出错：{str(e)}")


async def cmd_sub(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("用法：`/sub <频道名称或链接>`", parse_mode="Markdown")
        return
    uid = _uid(update)
    channel = " ".join(ctx.args).strip()
    channel_id = _normalize_channel(channel)
    db.add_subscription(uid, channel_id, channel)
    await update.message.reply_text(f"✅ 已订阅：{channel}\n\n有新视频时我会自动推送摘要。")


async def cmd_unsub(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    if not ctx.args:
        await update.message.reply_text("用法：`/unsub <频道ID>`", parse_mode="Markdown")
        return
    uid = _uid(update)
    channel_id = ctx.args[0].strip()
    db.remove_subscription(uid, channel_id)
    await update.message.reply_text(f"✅ 已取消订阅：{channel_id}")


async def cmd_list(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    uid = _uid(update)
    subs = db.get_subscriptions(uid)
    if not subs:
        await update.message.reply_text("你还没有订阅任何频道。\n用 `/sub <频道>` 开始订阅。", parse_mode="Markdown")
        return
    lines = [f"📡 *我的订阅（{len(subs)}个）*\n"]
    for s in subs:
        last = f"  最近更新：{s['last_updated'][:10]}" if s.get("last_updated") else ""
        lines.append(f"• {s['channel_name']} `{s['channel_id']}`{last}")
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


async def cmd_hot(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    _uid(update)
    videos = db.get_hot_videos(window_days=7, limit=5)
    videos = db.enrich_ago(videos)
    if not videos:
        await update.message.reply_text("暂无热门视频数据。")
        return
    lines = ["🔥 *本周热门（Top 5）*\n"]
    for i, v in enumerate(videos, 1):
        pts = (v.get("key_points") or [])[:1]
        pt  = f"\n  _{pts[0]}_" if pts else ""
        lines.append(
            f"{i}. *{v['title']}*\n"
            f"   {v['channel_name']} · {v.get('published_ago','')}{pt}\n"
            f"   {WEB_BASE}/share/{v['video_id']}\n"
        )
    await update.message.reply_text("\n".join(lines), parse_mode="Markdown")


# ── 推送回调（monitor 调用） ──────────────────────────────────


async def push_to_subscribers(video: dict, subscriber_user_ids: list[int]):
    """monitor.py 调用：向订阅用户推送新视频摘要。"""
    if not subscriber_user_ids:
        return

    text = _format_push(video)
    import sqlite3
    from db import DB_PATH

    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        for uid in subscriber_user_ids:
            row = c.execute("SELECT token FROM users WHERE id=? AND source='telegram'", (uid,)).fetchone()
            if not row:
                continue
            chat_id = int(row["token"])
            try:
                await _app.bot.send_message(chat_id=chat_id, text=text, parse_mode="Markdown")
            except Exception as e:
                print(f"[bot] push to {chat_id} failed: {e}")


# ── 格式化 ────────────────────────────────────────────────────


def _format_report(v: dict) -> str:
    pts = (v.get("key_points") or [])[:5]
    pts_text = "\n".join(f"• {p}" for p in pts) if pts else "（无要点）"
    return (
        f"📌 *{v.get('title','')}*\n"
        f"_{v.get('channel_name','')} · {v.get('duration','')}_{{\n\n}}"
        f"*核心要点*\n{pts_text}\n\n"
        f"🔗 {WEB_BASE}/share/{v['video_id']}"
    )


def _format_push(v: dict) -> str:
    pts = (v.get("key_points") or [])[:2]
    pts_text = "\n".join(f"• {p}" for p in pts) if pts else ""
    topic = f"[{v['topic']}] " if v.get("topic") else ""
    return (
        f"📡 *{topic}{v.get('title','')}*\n"
        f"_{v.get('channel_name','')}_\n\n"
        f"{pts_text}\n\n"
        f"完整摘要 → {WEB_BASE}/share/{v['video_id']}"
    )


# ── 工具 ─────────────────────────────────────────────────────


def _parse_vid(url: str) -> str | None:
    import re
    for p in [r"(?:v=|/)([0-9A-Za-z_-]{11})", r"youtu\.be/([0-9A-Za-z_-]{11})"]:
        m = re.search(p, url)
        if m:
            return m.group(1)
    if re.match(r"^[0-9A-Za-z_-]{11}$", url.strip()):
        return url.strip()
    return None


def _normalize_channel(channel: str) -> str:
    import re
    m = re.search(r"/channel/(UC[A-Za-z0-9_-]+)", channel)
    if m:
        return m.group(1)
    m = re.search(r"/@([A-Za-z0-9_.-]+)", channel)
    if m:
        return "@" + m.group(1)
    return channel.strip()


# ── 启动 ──────────────────────────────────────────────────────


_app: Application = None


def build_app() -> Application:
    builder = Application.builder().token(BOT_TOKEN)
    if PROXY_URL:
        from telegram import HTTPXRequest
        builder = builder.request(HTTPXRequest(proxy=PROXY_URL))
    application = builder.build()
    application.add_handler(CommandHandler("start",  cmd_start))
    application.add_handler(CommandHandler("watch",  cmd_watch))
    application.add_handler(CommandHandler("sub",    cmd_sub))
    application.add_handler(CommandHandler("unsub",  cmd_unsub))
    application.add_handler(CommandHandler("list",   cmd_list))
    application.add_handler(CommandHandler("hot",    cmd_hot))
    return application


async def run_bot():
    global _app
    _app = build_app()
    register_push(push_to_subscribers)
    print("[bot] 启动中…")
    await _app.initialize()
    await _app.start()
    await _app.updater.start_polling()
    print("[bot] 运行中，Ctrl+C 停止")
    # 保持运行
    await asyncio.Event().wait()


if __name__ == "__main__":
    asyncio.run(run_bot())
