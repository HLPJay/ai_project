"""
main.py — 统一启动入口
同时运行：FastAPI 服务 + 频道监控 + Telegram Bot
"""
import asyncio
import os

import uvicorn

from monitor import monitor_loop


async def run_server():
    config = uvicorn.Config(
        "server:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=False,
        log_level="info",
    )
    server = uvicorn.Server(config)
    await server.serve()


async def run_bot():
    if not os.getenv("TELEGRAM_BOT_TOKEN"):
        print("[main] 未设置 TELEGRAM_BOT_TOKEN，跳过 Bot 启动")
        return
    from telegram_bot import run_bot as _run_bot
    await _run_bot()


async def main():
    tasks = [
        asyncio.create_task(run_server(), name="server"),
        asyncio.create_task(monitor_loop(), name="monitor"),
        asyncio.create_task(run_bot(), name="telegram"),
    ]
    print("[main] 所有服务启动中…")
    try:
        await asyncio.gather(*tasks)
    except KeyboardInterrupt:
        print("\n[main] 收到停止信号，退出")
    finally:
        for t in tasks:
            t.cancel()


if __name__ == "__main__":
    asyncio.run(main())
