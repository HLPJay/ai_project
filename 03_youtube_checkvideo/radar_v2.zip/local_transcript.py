"""
local_transcript.py — 字幕获取
优先级：
  1. youtube-transcript-api（官方字幕，无需模型）
  2. yt-dlp 下载音频 → faster-whisper 本地转写（CUDA）
"""
import os
import re
import subprocess
import tempfile
from pathlib import Path

# ── youtube-transcript-api ────────────────────────────────────
try:
    from youtube_transcript_api import YouTubeTranscriptApi, NoTranscriptFound, TranscriptsDisabled
    HAS_TRANSCRIPT_API = True
except ImportError:
    HAS_TRANSCRIPT_API = False
    print("[transcript] youtube-transcript-api 未安装，将跳过官方字幕")

# ── faster-whisper ────────────────────────────────────────────
try:
    from faster_whisper import WhisperModel
    HAS_WHISPER = True
except ImportError:
    HAS_WHISPER = False
    print("[transcript] faster-whisper 未安装，语音转写不可用")

# CUDA dll 路径（Windows RTX 4070 环境）
_CUDA_DLL_PATH = os.getenv("CUDA_DLL_PATH", r"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v12.x\bin")
if os.name == "nt" and _CUDA_DLL_PATH:
    os.add_dll_directory(_CUDA_DLL_PATH)

# 全局 Whisper 模型（懒加载，首次使用才初始化）
_whisper_model = None
WHISPER_MODEL_SIZE = os.getenv("WHISPER_MODEL", "medium")
WHISPER_DEVICE = os.getenv("WHISPER_DEVICE", "cuda")
WHISPER_COMPUTE = os.getenv("WHISPER_COMPUTE", "float16")


def _get_whisper():
    global _whisper_model
    if _whisper_model is None and HAS_WHISPER:
        print(f"[transcript] 加载 Whisper {WHISPER_MODEL_SIZE} ({WHISPER_DEVICE})…")
        _whisper_model = WhisperModel(
            WHISPER_MODEL_SIZE,
            device=WHISPER_DEVICE,
            compute_type=WHISPER_COMPUTE,
        )
    return _whisper_model


# ── 主入口 ────────────────────────────────────────────────────


def get_transcript(video_id: str) -> dict | None:
    """
    获取视频字幕。返回字典：
    {
        text: str,          # 完整字幕文本
        title: str,         # 视频标题（可能为空）
        channel_id: str,
        channel_name: str,
        view_count: int,
        published_at: str,  # ISO 日期
        duration: str,      # "HH:MM:SS"
    }
    失败返回 None。
    """
    # 尝试 1：官方字幕 API
    result = _try_transcript_api(video_id)
    if result:
        return result

    # 尝试 2：Whisper 语音转写
    result = _try_whisper(video_id)
    if result:
        return result

    print(f"[transcript] {video_id} 所有方案均失败")
    return None


# ── 方案 1：youtube-transcript-api ───────────────────────────


def _try_transcript_api(video_id: str) -> dict | None:
    if not HAS_TRANSCRIPT_API:
        return None
    try:
        # 优先中文，回退英文
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        try:
            t = transcript_list.find_transcript(["zh-Hans", "zh-Hant", "zh"])
        except Exception:
            try:
                t = transcript_list.find_transcript(["en"])
            except Exception:
                t = transcript_list.find_manually_created_transcript(
                    transcript_list._manually_created_transcripts.keys()
                    or transcript_list._generated_transcripts.keys()
                )

        entries = t.fetch()
        text = " ".join(e["text"] for e in entries).replace("\n", " ")
        text = re.sub(r"\s+", " ", text).strip()

        meta = _fetch_meta(video_id)
        return {
            "text": text,
            "source": "transcript_api",
            **meta,
        }
    except (NoTranscriptFound, TranscriptsDisabled):
        print(f"[transcript] {video_id} 无官方字幕")
        return None
    except Exception as e:
        print(f"[transcript] transcript_api 失败: {e}")
        return None


# ── 方案 2：yt-dlp + faster-whisper ─────────────────────────


def _try_whisper(video_id: str) -> dict | None:
    if not HAS_WHISPER:
        return None

    model = _get_whisper()
    if not model:
        return None

    with tempfile.TemporaryDirectory() as tmpdir:
        audio_path = Path(tmpdir) / f"{video_id}.m4a"
        url = f"https://www.youtube.com/watch?v={video_id}"

        # 下载音频
        try:
            subprocess.run(
                [
                    "yt-dlp", "-f", "bestaudio[ext=m4a]/bestaudio",
                    "-o", str(audio_path), "--no-playlist", url,
                ],
                check=True, capture_output=True, timeout=120,
            )
        except Exception as e:
            print(f"[transcript] yt-dlp 下载失败: {e}")
            return None

        if not audio_path.exists():
            # yt-dlp 可能改了扩展名
            candidates = list(Path(tmpdir).glob(f"{video_id}.*"))
            if not candidates:
                return None
            audio_path = candidates[0]

        # Whisper 转写
        try:
            print(f"[transcript] Whisper 转写 {video_id}…")
            segments, info = model.transcribe(
                str(audio_path),
                language=None,   # 自动检测
                beam_size=5,
                vad_filter=True,
            )
            text = " ".join(seg.text for seg in segments).strip()
            meta = _fetch_meta(video_id)
            return {
                "text": text,
                "source": "whisper",
                "detected_language": info.language,
                **meta,
            }
        except Exception as e:
            print(f"[transcript] Whisper 转写失败: {e}")
            return None


# ── 元数据获取 ────────────────────────────────────────────────


def _fetch_meta(video_id: str) -> dict:
    """
    用 yt-dlp 获取视频元数据（标题、频道、时长等）。
    失败时返回空字典，不影响主流程。
    """
    try:
        import yt_dlp
        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(
                f"https://www.youtube.com/watch?v={video_id}", download=False
            )
        duration_s = info.get("duration", 0)
        h, m, s = duration_s // 3600, (duration_s % 3600) // 60, duration_s % 60
        return {
            "title":        info.get("title", ""),
            "channel_id":   info.get("channel_id", ""),
            "channel_name": info.get("uploader") or info.get("channel", ""),
            "view_count":   info.get("view_count", 0),
            "published_at": info.get("upload_date", ""),   # YYYYMMDD
            "duration":     f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}",
        }
    except Exception as e:
        print(f"[transcript] meta 获取失败: {e}")
        return {
            "title": "", "channel_id": "", "channel_name": "",
            "view_count": 0, "published_at": "", "duration": "",
        }
