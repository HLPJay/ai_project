"""schemas.py — 前后端数据契约，所有请求/响应模型"""
from pydantic import BaseModel


# ── 视频 ──────────────────────────────────────────────────────

class VideoOut(BaseModel):
    video_id:     str
    title:        str
    channel_id:   str = ""
    channel_name: str = ""
    view_count:   int = 0
    published_at: str = ""
    published_ago:str = ""
    duration:     str = ""
    topic:        str = ""
    key_points:   list[str] = []
    summary:      str = ""
    timestamps:   list[str] = []
    is_new:       bool = False


# ── 订阅 ──────────────────────────────────────────────────────

class SubOut(BaseModel):
    channel_id:   str
    channel_name: str
    topic:        str = ""
    last_updated: str = ""


class ChannelSearchOut(BaseModel):
    channel_id:       str
    channel_name:     str
    subscriber_count: int = 0
    description:      str = ""
    thumbnail:        str = ""


# ── 响应 ──────────────────────────────────────────────────────

class HotResponse(BaseModel):
    videos:     list[VideoOut]
    updated_at: str = ""


class VideoResponse(BaseModel):
    videos: list[VideoOut]


class SubResponse(BaseModel):
    subscriptions: list[SubOut]


class ChannelSearchResponse(BaseModel):
    channels: list[ChannelSearchOut]


class AskResponse(BaseModel):
    answer: str


class FeedbackStats(BaseModel):
    up:   int = 0
    down: int = 0


# ── 请求 Body ──────────────────────────────────────────────────

class SubBody(BaseModel):
    channel: str
    topic:   str = ""


class AskBody(BaseModel):
    video_id: str
    question: str


class FeedbackBody(BaseModel):
    video_id: str
    rating:   int   # 1 = 有用，-1 = 有问题
    comment:  str = ""
