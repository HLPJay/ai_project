# ARCHITECTURE.md

## 目录结构

```
radar/
├── config.py               # 所有配置（唯一读 env 的地方）
├── db.py                   # 数据库操作（唯一写 SQL 的地方）
├── schemas.py              # Pydantic 请求/响应模型
├── youtube_api.py          # YouTube Data API 封装
├── local_transcript.py     # 字幕获取
├── generate_report.py      # DeepSeek 报告生成
├── monitor.py              # 定时任务
├── telegram_bot.py         # Telegram Bot
├── main.py                 # 统一启动
├── server.py               # 路由注册（只 include_router）
├── routers/
│   ├── _auth.py            # require_user() 共享工具
│   ├── extract.py          # GET /report (SSE)
│   ├── hot.py              # GET /api/hot
│   ├── videos.py           # GET /api/videos  GET /api/search
│   ├── history.py          # GET /api/history
│   ├── ask.py              # POST /api/ask
│   ├── subscriptions.py    # GET/POST/DELETE /api/subscriptions
│   └── share.py            # GET /share/:id  GET /
└── templates/
    ├── index.html
    └── share.html
```

## DB Schema

```sql
users(id, token TEXT UNIQUE, source, tg_chat_id)
subscriptions(user_id→users, channel_id, channel_name, topic)
videos(video_id TEXT UNIQUE, channel_id, channel_name, title,
       view_count, published_at, duration, topic,
       key_points JSON, summary, timestamps JSON, keywords JSON)
user_history(user_id→users, video_id)
feedback(user_id→users, video_id, rating INT, comment)
videos_fts  -- FTS5，由 trigger 自动维护
```

## API 接口

```
GET  /                          主页面
GET  /report?url=&token=        SSE 提取进度
GET  /api/hot?window=7d         热门视频
GET  /api/videos?topics=        话题过滤
GET  /api/search?q=             全文搜索
GET  /api/history               用户提取历史
POST /api/ask                   追问 AI
GET  /api/subscriptions         订阅列表
POST /api/subscriptions         添加订阅
DEL  /api/subscriptions/:id     取消订阅
POST /api/feedback              摘要反馈
GET  /share/:video_id           分享卡片页
```

## VideoOut 字段（前后端契约）

```python
video_id, title, channel_id, channel_name,
view_count(int), published_at, published_ago,
duration, topic, key_points(list[str]),
summary, timestamps(list[str]), is_new(bool)
```
