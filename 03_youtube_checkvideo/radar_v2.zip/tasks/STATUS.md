# tasks/STATUS.md — 任务状态总览

Claude Code 每次执行任务后，将对应条目从 `[ ]` 改为 `[x]`。

## Phase 1 · 核心链路

- [x] 1.1 · config.py
- [x] 1.2 · schemas.py
- [ ] 1.3 · local_transcript 日期格式修复
- [x] 1.4 · routers/extract.py
- [x] 1.5 · routers/hot.py
- [x] 1.6 · routers/subscriptions.py
- [x] 1.7 · routers/videos.py
- [x] 1.8 · routers/history.py + ask.py
- [x] 1.9 · server.py 精简
- [ ] 1.10 · templates/share.html

## Phase 2 · 热门内容主动拉取

- [ ] 2.1 · youtube_api.py
- [ ] 2.2 · monitor.py 热门刷新

## Phase 3 · 质量反馈

- [ ] 3.1 · db.py feedback 表
- [ ] 3.2 · routers/feedback.py
- [ ] 3.3 · index.html 反馈按钮

## Phase 4 · 频道发现

- [ ] 4.1 · 频道搜索接口
- [ ] 4.2 · 前端订阅 Tab 搜索
