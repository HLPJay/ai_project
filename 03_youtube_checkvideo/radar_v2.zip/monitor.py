"""
monitor.py — 频道监控 + 定时处理
- 通过 YouTube RSS 检测新视频
- 调用字幕提取 + AI 报告生成
- 结果存库后通知 telegram_bot 推送
"""
import asyncio
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone

import httpx

import db
from generate_report import generate_report
from local_transcript import get_transcript

RSS_TEMPLATE = "https://www.youtube.com/feeds/videos.xml?channel_id={channel_id}"
CHECK_INTERVAL = int(__import__("os").getenv("MONITOR_INTERVAL", "900"))  # 秒，默认 15 分钟
MAX_VIDEOS_PER_RUN = 3   # 每个频道每次最多处理 N 个新视频，防止 API 超频

# ── 推送回调（telegram_bot.py 注入） ─────────────────────────
_push_callbacks: list = []

def register_push(callback):
    """telegram_bot.py 调用此函数注册推送回调。"""
    _push_callbacks.append(callback)


async def _push(video: dict, subscribers: list[int]):
    """通知所有已注册的推送回调。"""
    for cb in _push_callbacks:
        try:
            await cb(video, subscribers)
        except Exception as e:
            print(f"[monitor] push callback error: {e}")


# ── RSS 解析 ──────────────────────────────────────────────────


async def fetch_rss(channel_id: str) -> list[dict]:
    """从 YouTube RSS 获取最新视频列表（最多 15 条）。"""
    url = RSS_TEMPLATE.format(channel_id=channel_id)
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(url)
            resp.raise_for_status()
    except Exception as e:
        print(f"[monitor] RSS 获取失败 {channel_id}: {e}")
        return []

    ns = {
        "atom":  "http://www.w3.org/2005/Atom",
        "yt":    "http://www.youtube.com/xml/schemas/2015",
        "media": "http://search.yahoo.com/mrss/",
    }
    try:
        root = ET.fromstring(resp.text)
        videos = []
        for entry in root.findall("atom:entry", ns):
            vid_id = entry.findtext("yt:videoId", namespaces=ns)
            title  = entry.findtext("atom:title",   namespaces=ns)
            pub    = entry.findtext("atom:published", namespaces=ns)
            if vid_id:
                videos.append({"video_id": vid_id, "title": title, "published_at": pub})
        return videos
    except Exception as e:
        print(f"[monitor] RSS 解析失败 {channel_id}: {e}")
        return []


# ── 单视频处理 ────────────────────────────────────────────────


def process_video(video_id: str, title: str = "") -> dict | None:
    """
    处理单个视频：字幕 → AI 报告 → 存库。
    已处理过的直接从库里返回。
    """
    # 命中缓存
    cached = db.get_video(video_id)
    if cached:
        print(f"[monitor] 命中缓存 {video_id}")
        return cached

    print(f"[monitor] 处理视频 {video_id}…")

    # 字幕获取
    transcript_result = get_transcript(video_id)
    if not transcript_result or not transcript_result.get("text"):
        print(f"[monitor] {video_id} 无字幕，跳过")
        return None

    # AI 报告
    report = generate_report(
        transcript_result["text"],
        transcript_result.get("title") or title,
    )
    if not report:
        print(f"[monitor] {video_id} 报告生成失败，跳过")
        return None

    # 存库
    db.save_video(
        video_id=video_id,
        channel_id=transcript_result.get("channel_id", ""),
        channel_name=transcript_result.get("channel_name", ""),
        title=transcript_result.get("title") or title,
        key_points=report["key_points"],
        summary=report["summary"],
        timestamps=report.get("timestamps", []),
        keywords=report.get("keywords", []),
        view_count=transcript_result.get("view_count", 0),
        published_at=transcript_result.get("published_at", ""),
        duration=transcript_result.get("duration", ""),
        topic=report.get("topic", ""),
        transcript=transcript_result["text"],
    )

    return db.get_video(video_id)


# ── 主监控循环 ────────────────────────────────────────────────


async def monitor_loop():
    """定时扫描所有订阅频道，处理新视频并推送。"""
    print(f"[monitor] 启动，检查间隔 {CHECK_INTERVAL}s")
    while True:
        try:
            await _run_once()
        except Exception as e:
            print(f"[monitor] 循环异常: {e}")
        await asyncio.sleep(CHECK_INTERVAL)


async def _run_once():
    channels = db.get_all_subscribed_channels()
    if not channels:
        return

    print(f"[monitor] 检查 {len(channels)} 个频道…")
    loop = asyncio.get_event_loop()

    for ch in channels:
        channel_id   = ch["channel_id"]
        channel_name = ch["channel_name"]

        videos = await fetch_rss(channel_id)
        new_videos = [v for v in videos if not db.video_exists(v["video_id"])]

        if not new_videos:
            continue

        print(f"[monitor] {channel_name}: {len(new_videos)} 个新视频")

        # 找出订阅了这个频道的所有用户
        subscribers = _get_subscribers(channel_id)

        processed = 0
        for v in new_videos[:MAX_VIDEOS_PER_RUN]:
            result = await loop.run_in_executor(
                None, process_video, v["video_id"], v.get("title", "")
            )
            if result:
                result = db.enrich_ago([result])[0]
                await _push(result, subscribers)
                processed += 1
            # 避免短时间内大量请求 DeepSeek API
            await asyncio.sleep(3)

        print(f"[monitor] {channel_name}: 处理完成 {processed} 个")


def _get_subscribers(channel_id: str) -> list[int]:
    """获取订阅了某频道的所有用户 ID。"""
    import sqlite3
    from db import DB_PATH
    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        rows = c.execute(
            """SELECT DISTINCT u.id FROM users u
               JOIN subscriptions s ON s.user_id = u.id
               WHERE s.channel_id = ? AND u.source = 'telegram'""",
            (channel_id,),
        ).fetchall()
        return [r["id"] for r in rows]


if __name__ == "__main__":
    # 直接运行用于测试
    asyncio.run(monitor_loop())
