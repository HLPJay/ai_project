"""config.py — 统一配置，所有 env 只在这里读取"""
import os
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv(Path(__file__).parent / ".env")


@dataclass
class Settings:
    # AI
    DEEPSEEK_API_KEY: str = field(default_factory=lambda: os.getenv("DEEPSEEK_API_KEY", ""))

    # YouTube
    YOUTUBE_API_KEY: str = field(default_factory=lambda: os.getenv("YOUTUBE_API_KEY", ""))

    # Telegram
    TELEGRAM_BOT_TOKEN: str = field(default_factory=lambda: os.getenv("TELEGRAM_BOT_TOKEN", ""))
    TELEGRAM_PROXY: str = field(default_factory=lambda: os.getenv("TELEGRAM_PROXY", ""))

    # Server
    PORT: int = field(default_factory=lambda: int(os.getenv("PORT", "8000")))
    WEB_BASE_URL: str = field(default_factory=lambda: os.getenv("WEB_BASE_URL", "http://localhost:8000"))

    # Whisper
    WHISPER_MODEL: str = field(default_factory=lambda: os.getenv("WHISPER_MODEL", "medium"))
    WHISPER_DEVICE: str = field(default_factory=lambda: os.getenv("WHISPER_DEVICE", "cuda"))
    WHISPER_COMPUTE: str = field(default_factory=lambda: os.getenv("WHISPER_COMPUTE", "float16"))
    CUDA_DLL_PATH: str = field(default_factory=lambda: os.getenv("CUDA_DLL_PATH", ""))

    # Monitor
    MONITOR_INTERVAL: int = field(default_factory=lambda: int(os.getenv("MONITOR_INTERVAL", "900")))
    HOT_REFRESH_INTERVAL: int = field(default_factory=lambda: int(os.getenv("HOT_REFRESH_INTERVAL", "3600")))


settings = Settings()
