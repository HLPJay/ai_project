# CLAUDE.md

## 约束（每次必读）

**DB**：只调用 `db.py` 的函数，禁止在其他文件写 SQL  
**配置**：只从 `config.settings` 读取，禁止 `os.getenv()`  
**类型**：所有函数必须有类型注解  
**响应**：统一使用 `schemas.py` 中的 Pydantic 模型  
**异步**：同步阻塞调用用 `run_in_executor` 包装  
**错误**：外部 API 调用必须 try/except，禁止裸异常  
**认证**：所有 `/api/*` 路由调用 `routers/_auth.require_user(token)`

## 禁止改动（除非 Task 明确指定）

`db.py` · `generate_report.py` · `local_transcript.py` · `templates/index.html`

## 参考文档

目录结构 / DB Schema / API 列表 → `ARCHITECTURE.md`  
任务列表和状态 → `tasks/STATUS.md`  
单个任务规格 → `tasks/<id>-<name>.md`
