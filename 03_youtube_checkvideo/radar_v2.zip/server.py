"""server.py — 路由注册，不含任何业务逻辑"""
from fastapi import FastAPI
from fastapi.templating import Jinja2Templates

import db
from routers import extract, hot, videos, history, ask, subscriptions, share

db.init_db()

app = FastAPI(title="视频雷达", version="0.2.0")
templates = Jinja2Templates(directory="templates")

app.include_router(extract.router)
app.include_router(hot.router)
app.include_router(videos.router)
app.include_router(history.router)
app.include_router(ask.router)
app.include_router(subscriptions.router)
app.include_router(share.router)

if __name__ == "__main__":
    import uvicorn
    from config import settings
    uvicorn.run("server:app", host="0.0.0.0", port=settings.PORT, reload=True)
