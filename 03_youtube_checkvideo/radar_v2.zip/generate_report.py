"""
generate_report.py — AI 报告生成
使用 DeepSeek API，从字幕文本提取：
  - key_points（要点列表，数量由内容决定）
  - summary（完整摘要段落）
  - timestamps（时间轴，若原始字幕含时间戳）
  - keywords（用于话题聚合的关键词）
  - topic（自动分类）
"""
import json
import os
import re
import time
from openai import OpenAI

# DeepSeek 兼容 OpenAI SDK
_client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY", ""),
    base_url="https://api.deepseek.com",
)

TOPIC_LIST = ["人工智能", "地缘政治", "科技产品", "财经宏观", "气候能源", "创业投资", "科学探索", "文化社会"]

REPORT_PROMPT = """你是一位专业的信息分析师。请分析以下视频字幕，提取核心信息。

视频标题：{title}

字幕内容（可能已截断）：
{transcript}

请严格按以下 JSON 格式输出，不要输出任何其他内容：
{{
  "topic": "从这些分类中选一个最匹配的：{topics}",
  "key_points": ["要点1（完整一句话，含关键数据）", "要点2", "...（根据内容复杂度决定数量，3-8条）"],
  "summary": "200-400字的完整摘要，覆盖背景、核心论点、关键数据和结论",
  "keywords": ["关键词1", "关键词2", "关键词3"],
  "timestamps": ["MM:SS 章节名称", "...（如字幕中有时间标记则提取，否则为空数组）"]
}}

要求：
- key_points 每条必须是完整独立的信息，不要写成标题式短语
- summary 用连贯的段落，不要用列表
- keywords 提取 3-5 个，用于相似视频聚合
- 全部输出中文
"""

ASK_PROMPT = """你是视频内容助手。以下是视频的摘要信息：

{context}

用户问题：{question}

请基于以上视频内容回答。如果问题超出视频范围，说明"视频中未提及"并给出你的一般性知识。回答要简洁，200字以内。"""


def generate_report(transcript: str, title: str = "") -> dict | None:
    """
    从字幕文本生成结构化报告。
    返回包含 key_points / summary / keywords / topic / timestamps 的字典。
    """
    if not transcript:
        return None

    # 字幕过长时截断（DeepSeek 128K context，但费用考虑限制在 ~8K 字）
    max_chars = 12000
    if len(transcript) > max_chars:
        transcript = transcript[:max_chars] + "\n[字幕已截断]"

    prompt = REPORT_PROMPT.format(
        title=title,
        transcript=transcript,
        topics="、".join(TOPIC_LIST),
    )

    for attempt in range(3):
        try:
            resp = _client.chat.completions.create(
                model="deepseek-chat",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                max_tokens=2000,
            )
            raw = resp.choices[0].message.content.strip()
            return _parse_json(raw)
        except Exception as e:
            print(f"[report] attempt {attempt+1} failed: {e}")
            if attempt < 2:
                time.sleep(2 ** attempt)

    return None


def ask_about_video(context: str, question: str) -> str:
    """追问 AI：基于视频摘要回答问题。"""
    prompt = ASK_PROMPT.format(context=context, question=question)
    try:
        resp = _client.chat.completions.create(
            model="deepseek-chat",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.5,
            max_tokens=500,
        )
        return resp.choices[0].message.content.strip()
    except Exception as e:
        return f"AI 回答失败：{str(e)}"


def _parse_json(raw: str) -> dict | None:
    """健壮地从 LLM 输出中解析 JSON。"""
    # 去掉 ```json ... ``` 包裹
    raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.MULTILINE)
    raw = re.sub(r"\s*```$", "", raw, flags=re.MULTILINE)
    raw = raw.strip()

    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # 尝试提取第一个 { ... } 块
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if not m:
            print(f"[report] JSON parse failed:\n{raw[:200]}")
            return None
        try:
            data = json.loads(m.group())
        except Exception:
            return None

    # 字段校验 & 默认值
    return {
        "topic":      data.get("topic", ""),
        "key_points": data.get("key_points") or [],
        "summary":    data.get("summary", ""),
        "keywords":   data.get("keywords") or [],
        "timestamps": data.get("timestamps") or [],
    }
