# PLAN.md

每个 Task 格式：文件 · 输入 · 输出 · 验收条件 · 禁止改动

---

## Phase 1 — 核心链路跑通

### Task 1.1 · config.py
```
CREATE config.py
输出：Settings dataclass，从 .env 读取所有配置
字段：DEEPSEEK_API_KEY, YOUTUBE_API_KEY, TELEGRAM_BOT_TOKEN,
      TELEGRAM_PROXY, PORT(int,8000), WEB_BASE_URL,
      WHISPER_MODEL("medium"), WHISPER_DEVICE("cuda"),
      MONITOR_INTERVAL(int,900), CUDA_DLL_PATH
用法：from config import settings
```

### Task 1.2 · schemas.py
```
CREATE schemas.py
输出：Pydantic BaseModel 定义

VideoOut:
  video_id, title, channel_id, channel_name
  view_count(int), published_at, published_ago
  duration, topic, key_points(list[str])
  summary, timestamps(list[str]), is_new(bool)

SubOut:
  channel_id, channel_name, topic, last_updated

HotResponse:    videos(list[VideoOut]), updated_at(str)
VideoResponse:  videos(list[VideoOut])
SubResponse:    subscriptions(list[SubOut])
AskResponse:    answer(str)
SubBody:        channel(str), topic(str="")
AskBody:        video_id(str), question(str)
FeedbackBody:   video_id(str), rating(int), comment(str="")
```

### Task 1.3 · local_transcript.py 日期修复
```
MODIFY local_transcript.py → _fetch_meta()
问题：yt-dlp 返回 upload_date='20250409'，db 期望 '2025-04-09'
修复：
  raw = info.get('upload_date', '')
  published_at = f"{raw[:4]}-{raw[4:6]}-{raw[6:]}" if len(raw)==8 else raw
验收：get_transcript('任意ID') 返回的 published_at 格式为 YYYY-MM-DD
```

### Task 1.4 · routers/extract.py
```
EXTRACT from server.py → routers/extract.py
移动内容：/report SSE 端点 + _extract_stream() + _parse_video_id()
导入：from config import settings; from schemas import VideoOut
验收：router = APIRouter()，在 main_server.py include_router
禁止改动：db.py, generate_report.py
```

### Task 1.5 · routers/hot.py
```
EXTRACT from server.py → routers/hot.py
移动内容：GET /api/hot
导入：from schemas import HotResponse, VideoOut
验收：返回 HotResponse，window 参数支持 1d/7d/30d/90d
```

### Task 1.6 · routers/subscriptions.py
```
EXTRACT from server.py → routers/subscriptions.py
移动内容：GET/POST/DELETE /api/subscriptions + _normalize_channel()
导入：from schemas import SubResponse, SubBody, SubOut
```

### Task 1.7 · routers/videos.py
```
EXTRACT from server.py → routers/videos.py
移动内容：GET /api/videos + GET /api/search
```

### Task 1.8 · routers/history.py + routers/ask.py
```
EXTRACT from server.py
history.py：GET /api/history
ask.py：POST /api/ask
```

### Task 1.9 · server.py 精简
```
REWRITE server.py 为纯路由注册文件（<40行）
内容：创建 app，include_router 所有 routers，挂载 templates
禁止：业务逻辑留在 server.py
```

### Task 1.10 · templates/share.html
```
CREATE templates/share.html
数据：Jinja2 变量 {{ video }}，字段见 VideoOut
布局（固定宽 600px，可截图）：
  顶部：「视频雷达」logo（小字，右上角话题 badge）
  标题：Noto Serif SC，20px，最多3行
  副标题：频道名 · 时长 · published_ago
  分隔线
  要点：最多5条，每条前加 — 符号
  底部：「查看完整摘要 →」链接到 WEB_BASE_URL/
样式：复用 index.html 的 CSS 变量风格，暖白背景
验收：/share/任意video_id 渲染正常，不报 TemplateNotFound
```

---

## Phase 2 — 热门内容主动拉取

### Task 2.1 · youtube_api.py
```
CREATE youtube_api.py
依赖：httpx（已在 requirements.txt）
函数：
  fetch_trending(region='US', max_results=20) -> list[dict]
    调用 videos.list?chart=mostPopular
  
  search_by_topic(query, published_after_days=7,
                  max_results=20) -> list[dict]
    调用 search.list?order=viewCount
  
  get_channel_info(channel_id) -> dict
    调用 channels.list

返回格式统一：
  {'video_id','title','channel_id','channel_name',
   'view_count','published_at','duration','thumbnail'}

错误处理：配额不足(403)单独捕获并打印，不抛出
验收：fetch_trending() 返回非空列表（需真实 YOUTUBE_API_KEY）
```

### Task 2.2 · monitor.py 热门刷新
```
MODIFY monitor.py
新增：refresh_hot_videos() 异步函数
逻辑：
  TOPIC_QUERIES = ['artificial intelligence','geopolitics',
                   'tech news','economy finance']
  for q in TOPIC_QUERIES:
      videos = youtube_api.search_by_topic(q, published_after_days=7)
      new = [v for v in videos if not db.video_exists(v['video_id'])]
      for v in new[:3]:  # 每话题最多处理3个，防超频
          process_video(v['video_id'], v['title'])
          await asyncio.sleep(5)

新增：hot_refresh_loop() 每小时调用一次 refresh_hot_videos
MODIFY main.py：新增 create_task(hot_refresh_loop())
```

---

## Phase 3 — 质量反馈

### Task 3.1 · db.py 新增 feedback 表
```
MODIFY db.py → init_db()
新增表：
  feedback(id, user_id, video_id, rating INT, comment TEXT,
           created_at DEFAULT datetime('now'))
新增函数：
  save_feedback(user_id, video_id, rating, comment='') -> None
  get_video_feedback_stats(video_id) -> dict  # {up:int, down:int}
```

### Task 3.2 · routers/feedback.py
```
CREATE routers/feedback.py
POST /api/feedback  body: FeedbackBody
GET  /api/feedback/:video_id  返回 {up, down}
在 server.py include_router
```

### Task 3.3 · 前端 index.html 加反馈按钮
```
MODIFY templates/index.html
位置：详情抽屉 .dr-acts 区域
改动：在三个按钮后新增
  <button class="dact" onclick="doFeedback(1)">👍 有用</button>
  <button class="dact" onclick="doFeedback(-1)">👎 有问题</button>
JS 函数：
  async function doFeedback(rating) {
    await api('/api/feedback', {method:'POST',
      body: JSON.stringify({video_id: cur.video_id, rating})})
    toast(rating===1 ? '感谢反馈' : '已记录，帮助我们改进')
  }
禁止改动：其他 JS 逻辑、CSS
```

---

## Phase 4 — 频道发现

### Task 4.1 · routers/subscriptions.py 新增搜索
```
MODIFY routers/subscriptions.py
新增端点：GET /api/channels/search?q=&limit=5
调用：youtube_api.search_channels(q, limit)
返回：list[{channel_id, channel_name, subscriber_count, description}]
```

### Task 4.2 · 前端订阅 Tab 加搜索
```
MODIFY templates/index.html
位置：订阅 Tab，现有 .field-row 下方
新增：搜索结果区 #channelSearch
逻辑：输入框 input 事件（防抖300ms）→ GET /api/channels/search
      渲染频道卡片：名称 + 描述 + [订阅] 按钮
      点击[订阅] → 调用现有 doSub() 逻辑
```

---

## 执行顺序

```
1.1 → 1.2 → 1.3 → 1.4~1.9(可并行) → 1.10
→ 2.1 → 2.2
→ 3.1 → 3.2 → 3.3
→ 4.1 → 4.2
```

## 不要动的文件

任何 Phase 执行期间，以下文件除非 Task 明确指定否则禁止修改：
- `db.py`（除 Phase 3 Task 3.1）
- `templates/index.html`（除 Phase 3 Task 3.3 和 Phase 4 Task 4.2）
- `local_transcript.py`（除 Task 1.3）
- `generate_report.py`
